//
//  NewsDetailViewController.h
//  NewsApp


#import <UIKit/UIKit.h>
#import "NewsDisplay.h"
NS_ASSUME_NONNULL_BEGIN

@interface NewsDetailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *titileLbl;


@property (weak, nonatomic) IBOutlet UILabel *publishdateLbl;
@property (weak, nonatomic) IBOutlet UITextView *newsdescText;
@property (nonatomic, assign) NewsDisplay * display;

@end

NS_ASSUME_NONNULL_END
