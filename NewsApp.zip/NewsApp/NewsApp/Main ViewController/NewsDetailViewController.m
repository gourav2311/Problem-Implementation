//
//  NewsDetailViewController.m
//  NewsApp
//

#import "NewsDetailViewController.h"

@interface NewsDetailViewController ()

@end

@implementation NewsDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.titileLbl.text = self.display.title;
    self.publishdateLbl.text = [self.display publishDate];
    self.newsdescText.text = self.display.desc;
    [self setImage];
}

-(void)setImage{
    if (self.display.coverImage != nil){
        [self.imageView setImage:self.display.coverImage];
    }else
    if (self.display.imageUrl != (id)[NSNull null] && self.display.imageUrl.length != 0 ) {
        dispatch_async(dispatch_get_global_queue(0,0), ^{
                   NSData * data = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: self.display.imageUrl]];
                   if ( data == nil )
                       return;
                   dispatch_async(dispatch_get_main_queue(), ^{
                       UIImage *image = [UIImage imageWithData:data];
                       NSLog(@"%@",image);
                       self.display.coverImage = image;
                       [self.imageView setImage:image];

                   });
               });
    }else{
       
            [self.imageView setImage:nil];
            [self.imageView setBackgroundColor:UIColor.darkGrayColor];
       
    }
}
@end
