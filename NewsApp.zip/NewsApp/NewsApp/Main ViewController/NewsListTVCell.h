//
//  NewsListTVCell.m
//  NewsApp
//
#import <UIKit/UIKit.h>
#import "NewsDisplay.h"
@interface NewsListTVCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel * _Nullable lblTitle;
@property (weak, nonatomic) IBOutlet UILabel * _Nullable lblDate;
@property (weak, nonatomic) IBOutlet UILabel * _Nullable lblDesc;
@property (weak, nonatomic) IBOutlet UIImageView * _Nullable imgPoster;
- (void)setDisplay:(nullable NewsDisplay*)display;
@end
