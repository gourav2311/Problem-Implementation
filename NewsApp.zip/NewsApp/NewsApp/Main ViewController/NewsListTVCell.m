//
//  NewsListTVCell.m
//  NewsApp
//

#import "NewsListTVCell.h"
#import "NewsDisplay.h"
@implementation NewsListTVCell
@synthesize lblDesc,lblDate,lblTitle,imgPoster;

- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setDisplay:(nullable NewsDisplay *)display {
    [self.imgPoster setImage:nil];
    [self.imgPoster setBackgroundColor:UIColor.darkGrayColor];
    
    [self.lblTitle setText:display.title];
    [self.lblDate setText:[display publishDate]];
    [self.lblDesc setText:display.desc];
    
    if (display.coverImage != nil){
        [self.imgPoster setImage:display.coverImage];
    }else
    if (display.imageUrl != (id)[NSNull null] && display.imageUrl.length != 0 ) {
        dispatch_async(dispatch_get_global_queue(0,0), ^{
                   NSData * data = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: display.imageUrl]];
                   if ( data == nil )
                       return;
                   dispatch_async(dispatch_get_main_queue(), ^{
                       UIImage *image = [UIImage imageWithData:data];
                       NSLog(@"%@",image);
                       display.coverImage = image;
                       [self.imgPoster setImage:image];

                   });
               });
    }else{
       
            [self.imgPoster setImage:nil];
            [self.imgPoster setBackgroundColor:UIColor.darkGrayColor];
       
    }

}

@end
