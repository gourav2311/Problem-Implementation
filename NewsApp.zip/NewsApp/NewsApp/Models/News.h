//
//  News.h
//  NewsApp

#import <Foundation/Foundation.h>

#import <Foundation/Foundation.h>

@class NewsModel;
@class NewsArticle;
@class NewsSource;

NS_ASSUME_NONNULL_BEGIN

#pragma mark - Object interfaces

@interface NewsModel : NSObject
@property (nonatomic, nullable, copy)   NSString *status;
@property (nonatomic, nullable, strong) NSNumber *totalResults;
@property (nonatomic, nullable, copy)   NSArray<NewsArticle *> *articles;
@end

@interface News : NSObject
@property (nonatomic, nullable, strong) NewsSource *source;
@property (nonatomic, nullable, copy)   NSString *author;
@property (nonatomic, nullable, copy)   NSString *title;
@property (nonatomic, nullable, copy)   NSString *theDescription;
@property (nonatomic, nullable, copy)   NSString *url;
@property (nonatomic, nullable, copy)   id urlToImage;
@property (nonatomic, nullable, copy)   NSString *publishedAt;
@property (nonatomic, nullable, copy)   NSString *content;

- (instancetype)initWithTitle:(NSString*)title author:(NSString*)author theDescription:(NSString*)theDescription url:(NSString*)url urlToImage:(id)urlToImage publishedAt:(NSString*)publishedAt content:(NSString*)content;

@end

@interface NewsSource : NSObject
@property (nonatomic, nullable, copy) id identifier;
@property (nonatomic, nullable, copy) NSString *name;
- (instancetype)initWithName:(NSString*)name identifier:(id)identifier;
@end

NS_ASSUME_NONNULL_END

