//
//  News.m
//  NewsApp

#import "News.h"

@implementation News


- (instancetype)initWithTitle:(NSString*)title author:(NSString*)author theDescription:(NSString*)theDescription url:(NSString*)url urlToImage:(id)urlToImage publishedAt:(NSString*)publishedAt content:(NSString*)content{
    self = [super init];
    
    if (self) {
        self.title = title;
        self.author = author;
        self.theDescription = theDescription;
        self.url = url;
        self.urlToImage = urlToImage;
        self.publishedAt = publishedAt;
        self.content = content;
        
    }
    return self;
    
}



@end

@implementation NewsSource


- (instancetype)initWithName:(NSString*)name identifier:(id)identifier{
    self = [super init];
    
    if (self) {
        self.name = name;
        self.identifier = identifier;
        
    }
    return self;
}

@end
