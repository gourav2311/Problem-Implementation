//
//  NewsDisplay.h
//  NewsApp

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class News;
@interface NewsDisplay : NSObject

@property (nonatomic, nullable) NSString *title;
@property (nonatomic, nullable) NSString *date;
@property (nonatomic, nullable) NSString *desc;
@property (nonatomic, nullable) NSString *imageUrl;
@property (nonatomic, nullable) UIImage *coverImage;

- (instancetype)initWithNews:(nonnull News*)News;
-(NSString *)publishDate;
@end

NS_ASSUME_NONNULL_END
