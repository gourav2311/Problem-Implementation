//
//  NewsDisplay.m
//  NewsApp

#import "NewsDisplay.h"
#import "News.h"

@interface NewsDisplay()

@end

@implementation NewsDisplay


- (instancetype)initWithNews:(News*)news {
    self = [super init];
    if (self) {
        self.title = news.title;
        self.date = news.publishedAt;
        self.desc = news.theDescription;
        self.imageUrl = news.urlToImage;
    }
    return self;
}
-(NSString *)publishDate{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"];
    NSDate *date  = [dateFormatter dateFromString:self.date];

    // Convert to new Date Format
    [dateFormatter setDateFormat:@"yyyy-MMM-dd"];
    NSString *newDate = [dateFormatter stringFromDate:date];
    return newDate;
}
@end
