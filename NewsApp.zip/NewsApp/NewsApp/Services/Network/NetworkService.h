//
//  NetworkService.h
//  NewsApp

#import <Foundation/Foundation.h>
#import "NetworkServiceProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface NetworkService : NSObject<NetworkServiceProtocol>

@end

NS_ASSUME_NONNULL_END
