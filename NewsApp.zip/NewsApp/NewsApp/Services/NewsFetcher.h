//
//  NewsFetcher.h
//  NewsApp
#import <Foundation/Foundation.h>
#import "NewsFetcherProtocol.h"
#import "NetworkServiceProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface NewsFetcher : NSObject<NewsFetcherProtocol>

- (instancetype)initWithClient:(nonnull id<NetworkServiceProtocol>)client parser:(id<NewsParserProtocol>)parser;

@end

NS_ASSUME_NONNULL_END
