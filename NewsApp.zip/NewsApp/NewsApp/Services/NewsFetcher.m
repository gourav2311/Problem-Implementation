//
//  NewsFetcher.m
//  NewsApp
#import "NewsFetcher.h"


@interface NewsFetcher()

@property (nonatomic, strong) id<NewsParserProtocol> parser;
@property (nonatomic, strong) id<NetworkServiceProtocol> networkClient;

@end

@implementation NewsFetcher

- (instancetype)initWithClient:(nonnull id<NetworkServiceProtocol>)client parser:(id<NewsParserProtocol>)parser 
{
    self = [super init];
    if (self) {
        self.parser = parser;
        self.networkClient = client;
    }
    return self;
}


- (void)fetchNewssWithSuccess:(void (^)(NSArray<News *> *))successCompletion error:(void (^)(NSError *))errorCompletion {

    NSURL * url = [NSURL URLWithString:@"https://newsapi.org/v2/everything?q=Apple&from=2024-01-01&sortBy=popularity&apiKey=f43bc12806a5468885ec7d3b72ceb8be"];
    
    __weak NewsFetcher * weakSelf = self;
    void (^networksResponse)(NSData *) = ^(NSData *data){
        [weakSelf.parser parseNewss:data withSuccess:successCompletion error:errorCompletion];
    };
    
    // TODO: improve error handling at each steps
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        [weakSelf.networkClient getUrl:url withSuccess:networksResponse error:errorCompletion];
    });
}

/// Base on remote URL
- (void)fetchRemoteNewssWithSuccess:(void (^)(NSArray<News *> *))successCompletion error:(void (^)(NSError *))errorCompletion {
    
    NSURL * url = [NSURL URLWithString:@"https://myNewss..."];
    
    __weak NewsFetcher * weakSelf = self;
    void (^networksResponse)(NSData *) = ^(NSData *data){ 
        [weakSelf.parser parseNewss:data withSuccess:successCompletion error:errorCompletion];
    };
    
    // TODO: improve error handling at each steps
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        [weakSelf.networkClient getUrl:url withSuccess:networksResponse error:errorCompletion];
    });
}

@end
