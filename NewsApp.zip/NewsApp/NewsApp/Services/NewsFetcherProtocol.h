//
//  NewsFetcherProtocol.h
//  NewsApp
#import <Foundation/Foundation.h>

#ifndef NewsFetcherProtocol_h
#define NewsFetcherProtocol_h

#import "News.h"

@protocol NewsFetcherProtocol <NSObject>

- (void)fetchNewssWithSuccess:(void (^)(NSArray<News *> *Newss))successCompletion error:(void (^)(NSError *error))errorCompletion;

@end

@protocol NewsParserProtocol <NSObject>

- (void)parseNewss:(NSData *)data withSuccess:(void (^)(NSArray<News *> *Newss))successCompletion error:(void (^)(NSError *error))errorCompletion;

@end


#endif /* NewsFetcherProtocol_h */
