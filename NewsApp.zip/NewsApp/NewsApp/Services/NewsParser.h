//
//  NewsParser.h
//  NewsApp

#import <Foundation/Foundation.h>
#import "NewsFetcherProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface NewsParser : NSObject<NewsParserProtocol>

@end

NS_ASSUME_NONNULL_END
