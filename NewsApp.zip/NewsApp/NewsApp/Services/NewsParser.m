//
//  NewsParser.m
//  NewsApp

#import "NewsParser.h"

@implementation NewsParser

- (void)parseNewss:(NSData *)data withSuccess:(void (^)(NSArray<News *> *))successCompletion error:(void (^)(NSError *))errorCompletion {
    
    NSError *error;
    NSDictionary * jsonDictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
    
    if (!jsonDictionary || error) {
        // TODO: handle error better way
        errorCompletion(error);
        return;
    }
    
    NSArray *jsonArray = [jsonDictionary objectForKey:@"articles"];
    if (!jsonArray) {
        // TODO: handle error
        NSError * error = [NSError errorWithDomain:NSCocoaErrorDomain code:999 userInfo:nil];
        errorCompletion(error);
        return;
    }
    
    NSMutableArray<News *> *result = [[NSMutableArray alloc] init];
    for (NSDictionary *item in jsonArray) {
        
        // TODO: test fields
        NSString *title = [item objectForKey:@"title"];
        NSString *author = [item objectForKey:@"author"];
        NSString *description = [item objectForKey:@"description"];
        NSString *url = [item objectForKey:@"url"];
        NSString *urlToImage = [item objectForKey:@"urlToImage"];
        NSString *publishedAt = [item objectForKey:@"publishedAt"];
        NSString *content = [item objectForKey:@"content"];
        
    
        News * news = [[News alloc] initWithTitle:title author:author theDescription:description url:url urlToImage:urlToImage publishedAt:publishedAt content:content];
        
        [result addObject:news];
    }
    
    successCompletion(result);
}

@end
