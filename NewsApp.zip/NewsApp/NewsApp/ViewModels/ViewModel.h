//
//  ViewModel.h
//  NewsApp
//

#import <Foundation/Foundation.h>
#import "NewsDisplay.h"
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ViewModel : NSObject


- (void)getNewssWithSuccess:(void (^)(NSArray<NewsDisplay*> *displays))successCompletion error:(void (^)(NSError *error))errorCompletion;

- (NSUInteger)numberOfItems;
- (NSUInteger)numberOfSections;
- (nullable NewsDisplay *)itemAtIndexPath:(NSIndexPath *)indexPath;

@end

NS_ASSUME_NONNULL_END
