//
//  ViewModel.m
//  NewsApp

#import "ViewModel.h"

#import "NewsParser.h"
#import "NewsFetcher.h"
#import "NetworkService.h"

@interface ViewModel()

@property (nonatomic, strong) id<NewsFetcherProtocol> fetcher;
@property (nonatomic, strong) NSArray<NewsDisplay *> *items;

@end

@implementation ViewModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.items = @[];
        self.fetcher = [[NewsFetcher alloc] initWithClient:[[NetworkService alloc] init] parser:[[NewsParser alloc] init]];
    }
    return self;
}

- (void)getNewssWithSuccess:(void (^)(NSArray<NewsDisplay *> * _Nonnull))successCompletion error:(void (^)(NSError * _Nonnull))errorCompletion {
    
    __weak ViewModel *weakSelf = self;
    
    [self.fetcher fetchNewssWithSuccess:^(NSArray<News *> *Newss) {
        
        NSMutableArray * items = [[NSMutableArray alloc] init];
        for (News *News in Newss) {
            [items addObject:[[NewsDisplay alloc] initWithNews:News]]; 
        }
        [weakSelf setItems:items];
        successCompletion(items);
    } error:errorCompletion];
}

- (NSUInteger)numberOfItems {
    return self.items.count;
}

- (NSUInteger)numberOfSections {
    return 1;
}

- (NewsDisplay *)itemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row >= self.items.count) {
        return nil;
    }
    return self.items[indexPath.row];
}
@end
